module.exports.tables = require('./schema');
module.exports.checks = require('./checks');
module.exports.commands = require('./commands');
module.exports.defaultSettings = require('./default-settings');
